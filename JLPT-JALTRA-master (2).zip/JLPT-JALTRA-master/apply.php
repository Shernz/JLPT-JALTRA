<?php
echo "application page";
?>