<?php session_start();
$uname=$_REQUEST['email'];
$pass=$_REQUEST['passwd'];
$servername = "sql105.epizy.com";
$username = "epiz_25710276";
$password = "xt1KMNoVTJmdgqU";
$dbname = "epiz_25710276_register";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$passx='';
$sql="SELECT password from register WHERE email='$uname' ;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
       $passx= $row['password'];
    }
} else {
	
    echo "Invalid Username Or Password";
}
if (strcmp($passx,$pass)==0){
    
    header("Location: http://jlptchennai.epizy.com/JLPT-JALTRA-master/verify.php?id=".$uname);
    die();
}
else{
    //header("Location: http://127.0.0.1/JLPT-JALTRA-master/mainpage.php");
    $_SESSION['wrong']="wrong credentials";
	
	echo "Invalid Username Or Password";
    die();
}
$conn->close();

?>