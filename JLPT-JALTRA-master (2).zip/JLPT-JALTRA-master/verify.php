<?php
session_start();
//require_once('/home/vol15_5/epizy.com/epiz_25710276/htdocs/JLPT-JALTRA-master/transaction_details.csv');
$EMAIL = $_GET['id'];
$cell = 10000;
$flag=0;
$flag1=0;
$handle = fopen("/home/vol15_5/epizy.com/epiz_25710276/htdocs/JLPT-JALTRA-master/transaction_details.csv", "r");
while (($data = fgetcsv($handle)) !== FALSE) 
{   
	for ($i = 0; $i < count($data); $i++) 
	{    
		if($flag==0)
		{
			if($data[$i]==$EMAIL)
			{
				$flag=1; 
			}
		}
		else                                      
		{
			if($data[$i]=="success")
			{   
				$flag1=1;
				$_SESSION['email']=$EMAIL;
				header("Location: http://jlptchennai.epizy.com/JLPT-JALTRA-master/upload_form.php?id=".$EMAIL);
			}		
		}
	}
}
if($flag1==0 or $flag==0)
{   $i = 0; 
	$dir = 'uploads/';
	if ($handle = opendir($dir)) 
	{
		while (($file = readdir($handle)) !== false)
		{
			if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
				$i++;
		}
	}	
	$date="2020-10-1";
	if($i<3500 and (date("Y-m-d")<$date))
	{
		header("Location: http://jlptchennai.epizy.com/JLPT-JALTRA-master/jlpt");
	}
	else
	{
		echo "REGISTRATIONS CLOSED!!";
	}
}
?>