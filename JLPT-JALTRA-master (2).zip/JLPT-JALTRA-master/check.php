<?php session_start();
$given=$_REQUEST['otp'];
$actual=$_SESSION['otp'];

if (strcmp($given,$actual)==0){
    header("Location: http://jlptchennai.epizy.com/JLPT-JALTRA-master/register.php");
die();
}
else{
    header("Location: http://jlptchennai.epizy.com/JLPT-JALTRA-master/mainpage.php");
    die();
}
?>